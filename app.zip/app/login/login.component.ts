import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Users } from '../models/Users';
import { AuthService } from '../core/auth.service'
import { LoginService } from '../login/login.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  errorMessage: string;
  successMessage: string = null;
  user: Users = new Users();
  show: boolean;

  constructor(private form: FormBuilder, private svc: LoginService, private router: Router, private core: AuthService) { }

  ngOnInit(): void {
    this.loginForm = this.form.group({
      contactNumber: ["", [Validators.required, Validators.pattern("[9876][0-9]{9}")]],
      password: ["", Validators.required]
    })
  }

  login() {
    // console.log(this.loginForm.value);

    // this.svc.login(this.loginForm.value).subscribe(
    //   b=>this.a=b)

    this.svc.login(this.loginForm.value).subscribe(
      success => {
        sessionStorage.setItem("userId", success.userId.toString());
        this.core.nextUser(success);
        this.router.navigate(['/home']);

      },

      error => {
        this.errorMessage = 'Invalid Credentials. Try again.';
      }
    )
  }

  getRegisterPage() {

    //  You code goes here
  }




}
