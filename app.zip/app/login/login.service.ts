import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';

import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment'
import { Users } from '../models/Users'
import { AuthService } from '../core/auth.service'
@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private client: HttpClient, private auth: AuthService) { }

  login(data: any): Observable<Users> {
    return this.client.post<Users>(environment.loginUri, data);
    // .pipe(map(user => {
    //     localStorage.setItem('user', JSON.stringify(user));
    //     this.auth.nextUser(user);
    //     return user;
    // }));   
  }

}


