import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup, ReactiveFormsModule, FormArray, FormControl } from '@angular/forms';
import { RegisterService } from 'src/service/register.service';
import { Router } from '@angular/router';
import { CustomValidators } from './custom-validators';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {
  stateList: string[] = ["Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Delhi", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu Kashmir", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttarakhand", "Uttar Pradesh", "West Bengal"];
  flag: boolean;
  isEditable = false;
  errorMessage: string;
  successMessage: string;
  registerForm: FormGroup;
  rolesTypes: string[] = ["CUSTOMER", "VENDOR"];
  userRole: string;


  constructor(private fb: FormBuilder, private rs: RegisterService, private router: Router) { }

  ngOnInit() {
    this.registerForm = this.fb.group({
      userName: ["", [Validators.required, Validators.pattern("^[A-Za-z]+( [A-Za-z]+)*$")]],
      contactNumber: ["", [Validators.required, Validators.pattern("^(6|7|8|9)[0-9]{9}$")]],
      email: ["", [Validators.required, Validators.pattern("[A-Za-z]+[0-9]*[A-Za-z]*@[A-Za-z]+[.](com|in)")]],
      password: ["", [Validators.required, Validators.pattern(".*[A-z]+.*"),Validators.pattern(".*[a-z]+.*"),Validators.pattern(".*[0-9]+.*"),Validators.pattern(".*[!@#$%^&*].*")]],
      // confirmpassword: ["", [Validators.required, Validators.pattern("[A-Za-z0-9][!|@|#|$|%|^|&|*]{7,20}")]],
      //"^(?.=*[0-9](?.=*[a-z])(?.=*[A-Z](?.=*[!@#$%^&*](?.=\\S+$).{7,20}$))
      roleType: ["", Validators.required],
      userAddressName:["",Validators.required],
      addressline1: ["", Validators.required],
      addressline2: ["", Validators.required],
      area: ["", Validators.required],
      city: ["", Validators.required],
      userState: ["", Validators.required],
      pincode: ["", Validators.required]


    })


  }

  register() {
    //your code goes here
    this.successMessage = null;
    this.errorMessage = null;
    this.rs.register(this.registerForm.value).subscribe(
      success => {
        this.successMessage = "success";
        this.router.navigate(['/login'])
      },
      error => this.errorMessage = "User Registeration Failed"
    )
  }

  close() {

    //your code goes here
  }

  reload() {

    //your code goes here
  }
}



//aisha

