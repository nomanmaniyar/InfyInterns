export class Dish{
    dishId:number;
	dishName:string;
	dishCuisine:string;
	dishType:string;
	dishDescription:string;
	price:number;
	avgRating:number;
	speciality:string;
	imageUrl:string;
}