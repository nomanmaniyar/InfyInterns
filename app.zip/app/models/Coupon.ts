export class Coupon{
    couponId:number;
	couponCode:string;
	minimumBill:number;
	maximumRedemption:number;
	startDate:string;
	endDate:string;
}