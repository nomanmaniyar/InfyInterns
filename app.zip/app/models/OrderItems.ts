import { Dish } from './Dish';

export class OrderItems{
    orderItemsId:number;
	dish:Dish;
	qty:number;
}