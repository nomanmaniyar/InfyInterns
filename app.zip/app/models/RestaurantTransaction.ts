export class RestaurantTransaction{
    restaurantTransactionId:number;
	restaurantOrderCounter:number;
	restaurantApproxCost:number;
	restaurantStatus:boolean;
}