export class Roles{
    roleId:number;
    roleType:string;
}