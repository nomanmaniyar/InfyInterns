export class Wallet{
    walletId:number;
	availableAmount:number;
}