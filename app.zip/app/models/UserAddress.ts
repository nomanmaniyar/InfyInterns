export class UserAddress{
    userAddressId:number;
	userAddressName:string;
	addressLine1:string;
	addressLine2:string;
	area:string;
	city:string;
	userState:string;
	pincode:string;
}