import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AuthService } from 'src/app/core/auth.service';
import { Observable } from 'rxjs';
import { Restaurant } from 'src/app/models/Restaurant';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AreaRecommendationService {

  constructor(private http:HttpClient) { }

  getRestaurants(selectedArea: String):Observable<any>{

    return this.http.get(environment.getAreaRecommendations+selectedArea);
  }
}
