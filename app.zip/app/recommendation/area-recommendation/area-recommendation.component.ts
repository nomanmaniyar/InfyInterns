import { Component, OnInit } from '@angular/core';
import { Restaurant } from 'src/app/models/Restaurant';
import { AreaRecommendationService } from './area-recommendation.service';
import { AuthService } from 'src/app/core/auth.service';
import { Router } from '@angular/router';
import { UserAddress } from 'src/app/models/UserAddress';
import { UpdateAddressService } from 'src/app/user-address/update-address/update-address.service';

@Component({
  selector: 'app-area-recommendation',
  templateUrl: './area-recommendation.component.html',
  styleUrls: ['./area-recommendation.component.css']
})
export class AreaRecommendationComponent implements OnInit {

  restaurantList: Restaurant[];
  restListLength: number;
  userAddressList: UserAddress[];
  userAddress: UserAddress[];
  userName: String;
  selectedArea;
  errorMessage: String;
  area: String;

  constructor(private router: Router, private areaSer: UpdateAddressService, private recom: AreaRecommendationService) { }

  ngOnInit(): void {

    //your code goes here

    this.userName = sessionStorage.getItem("userId")

    this.areaSer.getUserList(this.userName).subscribe(
      a => {
        this.userAddressList = a.addressList
        console.log(this.userName)
        console.log(a)
      },
      err => console.log(err)
    )
    console.log(this.userAddress)

  }

  populateAddress() {

    //your code goes here
  }

  getRestaurants() {

    //your code goes here

    this.selectedArea=false;
    this.recom.getRestaurants(this.area).subscribe(
      response=>{this.restaurantList=response
      
      if(this.restaurantList.length>0){
        this.selectedArea=true;
      }
    console.log(this.restaurantList)},
    error=>this.errorMessage="Sorry!! Not Found."
    )


  }

  checkMenu(restaurantId) {

    //your code goes here
    this.router.navigate(['checkMenu/'+restaurantId])
  }

}
