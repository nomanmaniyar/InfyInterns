import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-delete-dish',
  templateUrl: './delete-dish.component.html',
  styleUrls: ['./delete-dish.component.css']
})
export class DeleteDishComponent implements OnInit {
flag : boolean=false;
  constructor() { }

  ngOnInit(): void {
  }
 

close(){
  
  //  You code goes here
}
}
