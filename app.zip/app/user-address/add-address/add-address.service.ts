import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserAddress } from 'src/app/models/UserAddress';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

const url = "http://localhost:4000/cibo/foodAdda/user/addAddress/";
@Injectable({
  providedIn: 'root'
})
export class AddAddressService {
  i: String=sessionStorage.getItem("userId");
 
  constructor(private http: HttpClient) { }

  addAddress(addressData: UserAddress): Observable<number> {
    var add:UserAddress=new UserAddress
    add.addressLine1=addressData.addressLine1;
    add.addressLine2=addressData.addressLine2;
    add.area=addressData.area;
    add.city=addressData.city;
    add.pincode=addressData.pincode;
    add.userState=addressData.userState;
    add.userAddressName=addressData.userAddressName;
   
  console.log(add);
    return this.http.post<number>(url+this.i,add);
  }
}
