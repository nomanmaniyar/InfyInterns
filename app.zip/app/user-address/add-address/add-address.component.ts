import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { AddAddressService } from './add-address.service';
import { Router } from '@angular/router';
import { UserAddress } from 'src/app/models/UserAddress';

@Component({
  selector: 'app-add-address',
  templateUrl: './add-address.component.html',
  styleUrls: ['./add-address.component.css']
})
export class AddAddressComponent implements OnInit {

  errorMessage: String = null;
  successMsg: String;
  addAddressForm: FormGroup;
  userAddressId: number;
  flag:boolean=false;
  userAddress: UserAddress;
  userId: String;

  userAddressList: UserAddress[];

  stateList: string[] = ["Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh","Delhi", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu Kashmir", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttarakhand", "Uttar Pradesh", "West Bengal"];
  constructor(private fb:FormBuilder, private addAddressService: AddAddressService, private router:Router) { }

  ngOnInit(): void {
    this.addAddressForm = this.fb.group({
      userAddressName: ["", [Validators.required]],
      addressLine1: ["", [Validators.required]],
      addressLine2: ["", [Validators.required]],
      area: ["", [Validators.required]],
      city: ["", [Validators.required ]],
      userState: ["", Validators.required],
      pincode: ["", Validators.required ]
    });
  }
  
  add() {
    this.errorMessage = null;
    if(this.addAddressForm.valid){
      this.addAddressService.addAddress(this.addAddressForm.value).subscribe((data) => {
        this.router.navigate(['/home/addressbook']);
      },
      (error) => this.errorMessage = error.error.message
      );
    } 
  }

  cancel(){

    // Your code goes here
  }

  close(){

  // Your code goes here
  }

  reload(){

   // Your code goes here
  }

}
