import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserAddress } from 'src/app/models/UserAddress';
import { Users } from 'src/app/models/Users';
import { environment } from 'src/environments/environment';


const url= "http://localhost:4000/cibo/UserAPI/updateAddress/";

@Injectable({
  providedIn: 'root'
})
export class UpdateAddressService {

  constructor(private http:HttpClient) { }

  delete(addressId: String, userId: String): Observable<String> {

    return this.http.delete<String>(environment.deleteAddress+userId+"/"+addressId);
  }

  getUserList(userId:String): Observable<Users>{

    return this.http.get<Users>(environment.getUser+userId);
  }
  update(addressData:UserAddress, userId:String) : Observable<any> {

    return this.http.put<any>(environment.updateAddress +userId,addressData);
}
}
