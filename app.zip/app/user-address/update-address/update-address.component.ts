import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup,ReactiveFormsModule, FormArray, FormControl, AbstractControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { UpdateAddressService } from './update-address.service';
import { UserAddress } from 'src/app/models/UserAddress';

@Component({
  selector: 'app-update-address',
  templateUrl: './update-address.component.html',
  styleUrls: ['./update-address.component.css']
})
export class UpdateAddressComponent implements OnInit {

  stateList: string[]=["Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Delhi","Goa","Gujarat","Haryana","Himachal Pradesh","Jammu Kashmir","Jharkhand","Karnataka","Kerala","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura","Uttarakhand","Uttar Pradesh","West Bengal"];
  flag:boolean;
  errorMessage: string;
  successMessage: string;
  updateForm: FormGroup;
  successMsg: String;
  address: any;
  
  userId: String;
  userAddressList: UserAddress[];
  userAddressId: number;
  userAddress: UserAddress

  constructor(private fb: FormBuilder, private updateAddressService: UpdateAddressService, private activatedRoute:ActivatedRoute, private router:Router) {
    this.userAddressId = parseInt(this.activatedRoute.snapshot.paramMap.get('id'));
    this.userId = sessionStorage.getItem("userId");
  }

  ngOnInit() {
    this.updateAddressService.getUserList(this.userId).subscribe(data => {
      this.userAddressList = data.addressList;
      this.userAddress = this.userAddressList.find(address => address.userAddressId == this.userAddressId)
      this.updateForm = this.fb.group({
        userAddressName: [this.userAddress.userAddressName, [Validators.required, this.validateUserAddress.bind(this)]],
        addressLine1: [this.userAddress.addressLine1, [Validators.required]],
        addressLine2: [this.userAddress.addressLine2, [Validators.required]],
        area: [this.userAddress.area, [Validators.required]],
        city: [this.userAddress.city, [Validators.required ]],
        userState: [this.userAddress.userState, Validators.required],
        pincode: [this.userAddress.pincode, Validators.required ]
      });
    });
  }
  
  validateUserAddress(control: AbstractControl){
    if (control && control.value) { 
      var usersAddresses = this.userAddressList.find(address => address.userAddressName == control.value.trim() && address.userAddressId != this.userAddressId)
      if(usersAddresses)
      {
        return {'alreadyexists': true};
      }
    }
  }

  update() {
    var address = new UserAddress();
    address.userAddressId = this.userAddressId;
    address.userAddressName = this.updateForm.value.userAddressName;
    address.addressLine1 = this.updateForm.value.addressLine1;
    address.addressLine2 = this.updateForm.value.addressLine2;
    address.area = this.updateForm.value.area;
    address.city = this.updateForm.value.city;
    address.userState = this.updateForm.value.userState;
    address.pincode = this.updateForm.value.pincode;
    if(this.updateForm.valid){
      this.updateAddressService.update(address,this.userId).subscribe();
      this.flag = true;
    }
  }

     
  close(){

        // Your code goes here
  }
}
function next(next: any, arg1: (success: any) => void, arg2: (error: any) => any) {
  throw new Error('Function not implemented.');
}
