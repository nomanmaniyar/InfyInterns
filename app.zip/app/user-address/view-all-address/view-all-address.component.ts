import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserAddress } from 'src/app/models/UserAddress';
import { UpdateAddressService } from '../update-address/update-address.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-view-all-address',
  templateUrl: './view-all-address.component.html',
  styleUrls: ['./view-all-address.component.css']
})
export class ViewAllAddressComponent implements OnInit {

  userAddressList: UserAddress[];
  userName: String;
  userId: String;

  error: String;
  flag: Boolean;
  addressDelete: String;
  mdelMsg: string = "Deleted successfully";
  constructor(private updateAddressService: UpdateAddressService,private router:Router) { }

  ngOnInit(): void {
    this.populateAddress();
  }

  populateAddress() {
    this.userId = sessionStorage.getItem("userId");
    this.updateAddressService.getUserList(this.userId).subscribe(
      data => this.userAddressList = data.addressList
    );
  }

  deleteAddress(addressId: number) {
    this.userId = sessionStorage.getItem("userId");
    this.updateAddressService.delete(addressId.toString(), this.userId).subscribe( data => {
      this.populateAddress();
    });
  }

  updateAddress(userAddress: UserAddress) {

    // Your code goes here
    this.router.navigate(['/updateAddress',userAddress.userAddressId])
    this.userId=sessionStorage.getItem("userId");
  }

  addAddress() {

    // Your code goes here
    this.router.navigate(['/addAddress'])
  }

}

